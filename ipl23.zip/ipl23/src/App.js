import React from "react";
import Accordion from "./components/Accordion";
import "./App.css";

import iplTeams from "./constants/IPLTeams";
export default function App() {
  return (
    <div className="App">
      <h1>LIST OF IPL TEAMS 2023</h1>
      <h2>Indian Premier League/Teams</h2>
      <div className="div_margin">
        {iplTeams &&
          iplTeams.map((team,index) => (
            <Accordion key={index}
              img={team.teamLogo}
              title={team.teamName}
              content={team.teamDesc}
            />
          ))}
      </div>
    </div>
  );
}
